<?php

define("SERVEUR","localhost");
define("USER","root");
define("PASSWORD","");
define("BDD","ex4");